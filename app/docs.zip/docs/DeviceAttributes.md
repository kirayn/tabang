# DeviceAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phoneNumber** | **string** |  | [optional] 
**make** | **string** |  | [optional] 
**model** | **string** |  | [optional] 
**provider** | **string** |  | [optional] 
**country** | **string** |  | [optional] 
**connectionType** | **string** |  | [optional] 
**battery** | **string** |  | [optional] 
**signalPercent** | **string** |  | [optional] 
**wifi** | **bool** |  | [optional] 
**lat** | **string** |  | [optional] 
**lng** | **string** |  | [optional] 
**lastSeen** | [**\DateTime**](\DateTime.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


