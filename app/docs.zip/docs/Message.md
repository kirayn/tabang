# Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**deviceId** | **int** |  | [optional] 
**message** | **string** |  | [optional] 
**status** | **string** |  | [optional] 
**log** | [**\SMSGatewayMe\Client\Model\MessageLog[]**](MessageLog.md) |  | [optional] 
**createdAt** | [**\DateTime**](\DateTime.md) |  | [optional] 
**updatedAt** | [**\DateTime**](\DateTime.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


